// async function login(email, password){
//   const res = await fetch("http://localhost:3000/api/users/login", {
//     method:"POST",
//     headers: {"Content-Type":"application/json"},
//     body: JSON.stringify({email,password})
//   });
//   const data = await res.json();
//   if(data.token){
//     localStorage.setItem("token", data.token);
//     localStorage.setItem("role", data.user.role);
//   }
//   return data;
// }
