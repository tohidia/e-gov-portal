



// import { useState } from "react";

// function CreateRequest() {
//   const [serviceId, setServiceId] = useState("");
//   const [documentName, setDocumentName] = useState("");
//   const [fee, setFee] = useState("");

//   const API_URL = import.meta.env.VITE_API_URL;

//   async function handleSubmit(e) {
//     e.preventDefault();
//     try {
//       const res = await fetch(`${API_URL}/requests`, {
//         method: "POST",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify({
//           citizen_id: 1,
//           service_id: serviceId,
//           document_name: documentName,
//           fee,
//         }),
//       });
//       if (!res.ok) throw new Error("Failed to submit request");
//       alert("Request submitted successfully!");
//       setServiceId("");
//       setDocumentName("");
//       setFee("");
//     } catch (err) {
//       alert(err.message);
//     }
//   }

//   return (
//     <form onSubmit={handleSubmit} className="flex gap-3">
//       <input
//         type="text"
//         value={serviceId}
//         onChange={(e) => setServiceId(e.target.value)}
//         placeholder="Service ID"
//         className="border rounded p-2 flex-1"
//       />
//       <input
//         type="text"
//         value={documentName}
//         onChange={(e) => setDocumentName(e.target.value)}
//         placeholder="Document Name (e.g., passport.pdf)"
//         className="border rounded p-2 flex-1"
//       />
//       <input
//         type="number"
//         value={fee}
//         onChange={(e) => setFee(e.target.value)}
//         placeholder="Fee"
//         className="border rounded p-2 w-28"
//       />
//       <button
//         type="submit"
//         className="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700"
//       >
//         Submit Request
//       </button>
//     </form>
//   );
// }

// export default CreateRequest;



// import { useState, useEffect } from "react";
// import { toast } from "react-toastify";

// export default function CreateRequest() {
//   const [services, setServices] = useState([]);
//   const [serviceId, setServiceId] = useState("");
//   const [file, setFile] = useState(null);
//   const [fee, setFee] = useState("");

//   const API_URL = import.meta.env.VITE_API_URL;

//   useEffect(() => {
//     fetch(`${API_URL}/services`)
//       .then(res => res.json())
//       .then(data => setServices(data))
//       .catch(err => console.error(err));
//   }, []);

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     if (!serviceId || !file || !fee) {
//       toast.error("لطفاً همه فیلدها را پر کنید!");
//       return;
//     }

//     const formData = new FormData();
//     formData.append("user_id", 1); // یا ID کاربر وارد شده
//     formData.append("service_id", serviceId);
//     formData.append("fee", fee);
//     formData.append("documents", file);

//     try {
//       const res = await fetch(`${API_URL}/requests`, {
//         method: "POST",
//         body: formData,
//       });
//       if (!res.ok) throw new Error("Failed to create request");
//       toast.success("Request submitted successfully!");
//       setServiceId(""); setFee(""); setFile(null);
//     } catch (err) {
//       toast.error(err.message);
//     }
//   };

//   return (
//     <div className="max-w-xl mx-auto p-6 bg-white shadow-2xl rounded-3xl mt-10">
//       <h2 className="text-2xl font-bold mb-4 text-center">Create New Request</h2>
//       <form onSubmit={handleSubmit} className="space-y-4">
//         <select
//           value={serviceId}
//           onChange={(e) => setServiceId(e.target.value)}
//           className="w-full p-3 border rounded-xl focus:ring-2 focus:ring-indigo-500"
//         >
//           <option value="">Select Service</option>
//           {services.map(s => (
//             <option key={s.id} value={s.id}>{s.name}</option>
//           ))}
//         </select>

//         <input
//           type="file"
//           onChange={(e) => setFile(e.target.files[0])}
//           className="w-full"
//         />

//         <input
//           type="number"
//           value={fee}
//           onChange={(e) => setFee(e.target.value)}
//           placeholder="Fee"
//           className="w-full p-3 border rounded-xl focus:ring-2 focus:ring-indigo-500"
//         />

//         <button
//           type="submit"
//           className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-3 rounded-xl font-semibold transition"
//         >
//           Submit Request
//         </button>
//       </form>
//     </div>
//   );
// }



// // CreateRequest.jsx
// import { useEffect, useState } from "react";
// import { toast } from "react-toastify";

// export default function CreateRequest() {
//   const [services, setServices] = useState([]);
//   const [serviceId, setServiceId] = useState("");
//   const [documentName, setDocumentName] = useState("");
//   const [fee, setFee] = useState("");

//   const API_URL = "http://localhost:3000/api";

//   // Load Services
//   useEffect(() => {
//     fetch(`${API_URL}/services`)
//       .then((res) => res.json())
//       .then((data) => setServices(data))
//       .catch((err) => toast.error("Failed to load services"));
//   }, []);

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     if (!serviceId || !documentName || !fee) return toast.error("All fields are required");

//     try {
//       const res = await fetch(`${API_URL}/requests`, {
//         method: "POST",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify({
//           user_id: 1, // نمونه کاربر
//           service_id: serviceId,
//           documents: [documentName],
//           fee,
//         }),
//       });
//       if (!res.ok) throw new Error("Failed to submit request");
//       toast.success("Request submitted successfully!");
//       setServiceId("");
//       setDocumentName("");
//       setFee("");
//     } catch (err) {
//       toast.error(err.message);
//     }
//   };

//   return (
//     <form
//       onSubmit={handleSubmit}
//       className="bg-white p-6 rounded-3xl shadow-lg max-w-2xl mx-auto flex flex-col gap-4"
//     >
//       <h2 className="text-2xl font-bold text-indigo-700 mb-4">Create Request</h2>

//       <select
//         value={serviceId}
//         onChange={(e) => setServiceId(e.target.value)}
//         className="border rounded p-3"
//       >
//         <option value="">Select Service</option>
//         {services.map((s) => (
//           <option key={s.id} value={s.id}>
//             {s.name}
//           </option>
//         ))}
//       </select>

//       <input
//         type="text"
//         placeholder="Document Name (e.g., passport.pdf)"
//         value={documentName}
//         onChange={(e) => setDocumentName(e.target.value)}
//         className="border rounded p-3"
//       />

//       <input
//         type="number"
//         placeholder="Fee"
//         value={fee}
//         onChange={(e) => setFee(e.target.value)}
//         className="border rounded p-3"
//       />

//       <button
//         type="submit"
//         className="bg-indigo-600 text-white px-6 py-3 rounded-full hover:bg-indigo-700 transition"
//       >
//         Submit Request
//       </button>
//     </form>
//   );
// }



import { useEffect, useState } from "react";
import { toast } from "react-toastify";

export default function CreateRequest() {
  const [services, setServices] = useState([]);
  const [serviceId, setServiceId] = useState("");
  const [documentName, setDocumentName] = useState("");
  const [fee, setFee] = useState("");
  const API_URL = "http://localhost:3000/api";

  // 📌 گرفتن توکن از localStorage
  const token = localStorage.getItem("token");

  // 🧩 گرفتن لیست سرویس‌ها
  useEffect(() => {
    fetch(`${API_URL}/services`)
      .then((res) => {
        if (!res.ok) throw new Error("Failed to load services");
        return res.json();
      })
      .then((data) => setServices(data))
      .catch(() => toast.error("❌ Failed to load services"));
  }, []);

  // 📨 ارسال درخواست جدید
  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!serviceId || !documentName || !fee) {
      toast.error("⚠️ All fields are required");
      return;
    }

    if (!token) {
      toast.error("🚫 You must be logged in to send a request");
      return;
    }

    try {
      const res = await fetch(`${API_URL}/requests`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`, // 🔥 ارسال توکن
        },
        body: JSON.stringify({
          service_id: serviceId,
          documents: [documentName],
          fee,
        }),
      });

      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.message || "Failed to submit request");
      }

      toast.success("✅ Request submitted successfully!");
      setServiceId("");
      setDocumentName("");
      setFee("");
    } catch (err) {
      toast.error(`❌ ${err.message}`);
      console.error("Request error:", err);
    }
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="bg-white p-6 rounded-3xl shadow-lg max-w-2xl mx-auto flex flex-col gap-4"
    >
      <h2 className="text-2xl font-bold text-indigo-700 mb-4">
        Create Request
      </h2>

      {/* 🧾 انتخاب سرویس */}
      <select
        value={serviceId}
        onChange={(e) => setServiceId(e.target.value)}
        className="border rounded p-3"
      >
        <option value="">Select Service</option>
        {services.map((s) => (
          <option key={s.id} value={s.id}>
            {s.name}
          </option>
        ))}
      </select>

      {/* 📎 نام سند */}
      <input
        type="text"
        placeholder="Document Name (e.g., passport.pdf)"
        value={documentName}
        onChange={(e) => setDocumentName(e.target.value)}
        className="border rounded p-3"
      />

      {/* 💰 هزینه */}
      <input
        type="number"
        placeholder="Fee"
        value={fee}
        onChange={(e) => setFee(e.target.value)}
        className="border rounded p-3"
      />

      <button
        type="submit"
        className="bg-indigo-600 text-white px-6 py-3 rounded-full hover:bg-indigo-700 transition"
      >
        Submit Request
      </button>
    </form>
  );
}
