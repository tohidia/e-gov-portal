// middleware/authMiddleware.js
// import jwt from 'jsonwebtoken';
// import dotenv from 'dotenv';

// dotenv.config();

// export const verifyToken = (req, res, next) => {
//   const authHeader = req.headers.authorization;

//   if (!authHeader || !authHeader.startsWith('Bearer ')) {
//     return res.status(401).json({ message: 'Access denied. No token provided.' });
//   }

//   const token = authHeader.split(' ')[1];

//   try {
//     const decoded = jwt.verify(token, process.env.JWT_SECRET);
//     req.user = decoded;
//     next();
//   } catch (err) {
//     res.status(400).json({ message: 'Invalid or expired token.' });
//   }
// };

// export const adminOnly = (req, res, next) => {
//   if (!req.user || req.user.role !== 'admin') {
//     return res.status(403).json({ message: 'Access denied. Admins only.' });
//   }
//   next();
// };

// export const citizenOnly = (req, res, next) => {
//   if (!req.user || req.user.role !== 'citizen') {
//     return res.status(403).json({ message: 'Access denied. Citizens only.' });
//   }
//   next();
// };


// import jwt from 'jsonwebtoken';
// import dotenv from 'dotenv';

// dotenv.config();

// export const verifyToken = (req, res, next) => {
//   const authHeader = req.headers.authorization;
//   if (!authHeader || !authHeader.startsWith('Bearer ')) {
//     return res.status(401).json({ message: 'Access denied. No token provided.' });
//   }

//   const token = authHeader.split(' ')[1];
//   try {
//     const decoded = jwt.verify(token, process.env.JWT_SECRET);
//     req.user = decoded; // { id, role }
//     next();
//   } catch (err) {
//     res.status(400).json({ message: 'Invalid or expired token.' });
//   }
// };

// export const adminOnly = (req, res, next) => {
//   if (!req.user || req.user.role !== 'admin') {
//     return res.status(403).json({ message: 'Access denied. Admins only.' });
//   }
//   next();
// };

// export const citizenOnly = (req, res, next) => {
//   if (!req.user || req.user.role !== 'citizen') {
//     return res.status(403).json({ message: 'Access denied. Citizens only.' });
//   }
//   next();
// };

// import jwt from 'jsonwebtoken';
// import dotenv from 'dotenv';
// dotenv.config();

// export const verifyToken = (req, res, next) => {
//   const authHeader = req.headers.authorization;
//   if (!authHeader || !authHeader.startsWith('Bearer ')) {
//     return res.status(401).json({ message: 'Access denied. No token provided.' });
//   }
//   const token = authHeader.split(' ')[1];
//   try {
//     const decoded = jwt.verify(token, process.env.JWT_SECRET);
//     req.user = decoded;
//     next();
//   } catch (err) {
//     res.status(400).json({ message: 'Invalid or expired token.' });
//   }
// };

// export const adminOnly = (req, res, next) => {
//   if (!req.user || req.user.role !== 'admin') {
//     return res.status(403).json({ message: 'Access denied. Admins only.' });
//   }
//   next();
// };

// export const citizenOnly = (req, res, next) => {
//   if (!req.user || req.user.role !== 'citizen') {
//     return res.status(403).json({ message: 'Access denied. Citizens only.' });
//   }
//   next();
// };


// import jwt from "jsonwebtoken";
// import dotenv from "dotenv";
// dotenv.config();

// export const verifyToken = (req, res, next) => {
//   // توکن را از Header یا Cookie بگیر
//   const authHeader = req.headers.authorization;
//   const token = authHeader?.startsWith("Bearer ")
//     ? authHeader.split(" ")[1]
//     : req.cookies?.token;

//   if (!token) {
//     return res.status(401).json({ message: "Access denied. No token provided." });
//   }

//   try {
//     const decoded = jwt.verify(token, process.env.JWT_SECRET);
//     req.user = decoded;
//     next();
//   } catch (err) {
//     console.error("JWT error:", err);
//     res.status(400).json({ message: "Invalid or expired token." });
//   }
// };

// export const adminOnly = (req, res, next) => {
//   if (!req.user || req.user.role !== "admin") {
//     return res.status(403).json({ message: "Access denied. Admins only." });
//   }
//   next();
// };

// export const citizenOnly = (req, res, next) => {
//   if (!req.user || req.user.role !== "citizen") {
//     return res.status(403).json({ message: "Access denied. Citizens only." });
//   }
//   next();
// };




// import jwt from "jsonwebtoken";
// import dotenv from "dotenv";
// dotenv.config();

// export const verifyToken = (req, res, next) => {
//   // ✅ دریافت توکن از Header
//   const authHeader = req.headers.authorization;
//   const token = authHeader?.startsWith("Bearer ")
//     ? authHeader.split(" ")[1]
//     : null;

//   if (!token) {
//     console.warn("🚫 No token provided in request headers");
//     return res.status(401).json({ message: "Access denied. No token provided." });
//   }

//   try {
//     const decoded = jwt.verify(token, process.env.JWT_SECRET);
//     req.user = decoded;
//     next();
//   } catch (err) {
//     console.error("JWT error:", err.message);
//     res.status(400).json({ message: "Invalid or expired token." });
//   }
// };

// export const adminOnly = (req, res, next) => {
//   if (!req.user || req.user.role !== "admin") {
//     return res.status(403).json({ message: "Access denied. Admins only." });
//   }
//   next();
// };

// export const citizenOnly = (req, res, next) => {
//   if (!req.user || req.user.role !== "citizen") {
//     return res.status(403).json({ message: "Access denied. Citizens only." });
//   }
//   next();
// };




// import jwt from "jsonwebtoken";
// import dotenv from "dotenv";
// dotenv.config();

// // 🔹 بررسی JWT از Header
// export const verifyToken = (req, res, next) => {
//   const authHeader = req.headers.authorization;
//   const token = authHeader?.startsWith("Bearer ")
//     ? authHeader.split(" ")[1]
//     : null;

//   if (!token) {
//     console.warn("🚫 No token provided in request headers");
//     return res.status(401).json({ message: "Access denied. No token provided." });
//   }

//   try {
//     const decoded = jwt.verify(token, process.env.JWT_SECRET);
//     req.user = decoded;
//     next();
//   } catch (err) {
//     console.error("JWT error:", err.message);
//     res.status(400).json({ message: "Invalid or expired token." });
//   }
// };

// // 🔹 دسترسی فقط برای admin
// export const adminOnly = (req, res, next) => {
//   if (!req.user || req.user.role !== "admin") {
//     return res.status(403).json({ message: "Access denied. Admins only." });
//   }
//   next();
// };

// // 🔹 دسترسی فقط برای citizen
// export const citizenOnly = (req, res, next) => {
//   if (!req.user || req.user.role !== "citizen") {
//     return res.status(403).json({ message: "Access denied. Citizens only." });
//   }
//   next();
// };

// // 🔹 دسترسی برای همه کاربران معتبر (نقش اهمیتی ندارد)
// export const authOnly = (req, res, next) => {
//   if (!req.user) {
//     return res.status(401).json({ message: "Unauthorized. Token required." });
//   }
//   next();
// };






// import jwt from "jsonwebtoken";
// import dotenv from "dotenv";

// dotenv.config();

// /**
//  * ✅ Middleware: verifyToken
//  * بررسی توکن JWT
//  */
// export const verifyToken = (req, res, next) => {
//   const authHeader = req.headers.authorization;

//   if (!authHeader) {
//     return res.status(401).json({ message: "Access denied. No token provided." });
//   }

//   const token = authHeader.split(" ")[1];

//   try {
//     const secretKey = process.env.JWT_SECRET || "secret_key";
//     const decoded = jwt.verify(token, secretKey);

//     req.user = decoded;
//     next();
//   } catch (err) {
//     return res.status(401).json({ message: "Invalid or expired token." });
//   }
// };

// /**
//  * ✅ Middleware: adminOnly
//  * فقط مدیرها می‌توانند وارد شوند
//  */
// export const adminOnly = (req, res, next) => {
//   if (req.user && req.user.role === "admin") {
//     next();
//   } else {
//     return res.status(403).json({ message: "Access denied. Admins only." });
//   }
// };

// /**
//  * ✅ Middleware: citizenOnly
//  * فقط کاربران با نقش citizen می‌توانند وارد شوند
//  */
// export const citizenOnly = (req, res, next) => {
//   if (req.user && req.user.role === "citizen") {
//     next();
//   } else {
//     return res.status(403).json({ message: "Access denied. Citizens only." });
//   }
// };




// import jwt from "jsonwebtoken";
// import dotenv from "dotenv";

// dotenv.config();

// // 🟢 بررسی و تأیید JWT
// export const verifyToken = (req, res, next) => {
//   try {
//     const authHeader = req.headers.authorization;
//     const token = authHeader?.startsWith("Bearer ")
//       ? authHeader.split(" ")[1]
//       : req.cookies?.token;

//     if (!token) {
//       console.warn("🚫 No token provided in request headers");
//       return res.status(401).json({ message: "Access denied. No token provided." });
//     }

//     const decoded = jwt.verify(token, process.env.JWT_SECRET);
//     req.user = decoded; 
//     next();
//   } catch (err) {
//     console.error("JWT error:", err.message);
//     if (err.name === "TokenExpiredError") {
//       return res.status(401).json({ message: "JWT expired. Please log in again." });
//     }
//     return res.status(400).json({ message: "Invalid token." });
//   }
// };

// // 🟣 مسیر مخصوص ادمین‌ها
// export const adminOnly = (req, res, next) => {
//   if (!req.user || req.user.role !== "admin") {
//     return res.status(403).json({ message: "Access denied. Admins only." });
//   }
//   next();
// };

// // 🟢 مسیر مخصوص کاربران عادی (شهروند)
// export const citizenOnly = (req, res, next) => {
//   if (!req.user || req.user.role !== "citizen") {
//     return res.status(403).json({ message: "Access denied. Citizens only." });
//   }
//   next();
// };


// import jwt from "jsonwebtoken";
// import dotenv from "dotenv";

// dotenv.config();

// // 🟢 بررسی و تأیید JWT
// export const verifyToken = (req, res, next) => {
//   try {
//     const authHeader = req.headers.authorization;
//     const token = authHeader?.startsWith("Bearer ")
//       ? authHeader.split(" ")[1]
//       : req.cookies?.token;

//     if (!token) {
//       return res.status(401).json({ message: "Access denied. No token provided." });
//     }

//     const decoded = jwt.verify(token, process.env.JWT_SECRET);
//     req.user = decoded;
//     next();
//   } catch (err) {
//     if (err.name === "TokenExpiredError") {
//       return res.status(401).json({ message: "JWT expired. Please log in again." });
//     }
//     return res.status(400).json({ message: "Invalid token." });
//   }
// };

// // 🟣 مسیر مخصوص ادمین‌ها
// export const adminOnly = (req, res, next) => {
//   if (!req.user || req.user.role !== "admin") {
//     return res.status(403).json({ message: "Access denied. Admins only." });
//   }
//   next();
// };

// // 🟢 مسیر مخصوص کاربران عادی (شهروند)
// export const citizenOnly = (req, res, next) => {
//   if (!req.user || req.user.role !== "citizen") {
//     return res.status(403).json({ message: "Access denied. Citizens only." });
//   }
//   next();
// };



import jwt from "jsonwebtoken";
import dotenv from "dotenv";

dotenv.config();

/**
 * 🟢 Middleware: Verify JWT Token (Header → Cookie)
 */
export const verifyToken = (req, res, next) => {
  try {
    let token = null;

    // 1) Authorization Header → Bearer token
    if (req.headers.authorization?.startsWith("Bearer ")) {
      token = req.headers.authorization.split(" ")[1];
    }

    // 2) Cookie Token
    if (!token && req.cookies?.token) {
      token = req.cookies.token;
    }

    if (!token) {
      return res
        .status(401)
        .json({ message: "Access denied. No token provided." });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    req.user = decoded; // { id, role, ... }

    next();
  } catch (err) {
    if (err.name === "TokenExpiredError") {
      return res.status(401).json({ message: "JWT expired. Please log in again." });
    }
    return res.status(401).json({ message: "Invalid token." });
  }
};

/**
 * 🟣 Middleware: Admin-only
 */
export const adminOnly = (req, res, next) => {
  if (!req.user || req.user.role !== "admin") {
    return res
      .status(403)
      .json({ message: "Access denied. Admins only." });
  }
  next();
};

/**
 * 🔵 Middleware: Citizen-only
 */
export const citizenOnly = (req, res, next) => {
  if (!req.user || req.user.role !== "citizen") {
    return res
      .status(403)
      .json({ message: "Access denied. Citizens only." });
  }
  next();
};

